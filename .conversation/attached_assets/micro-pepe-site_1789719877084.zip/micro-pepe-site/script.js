const growBtn = document.getElementById('growBtn');
const microPepe = document.getElementById('microPepe');
const sizeTag = document.getElementById('sizeTag');
const microscopeBtn = document.getElementById('microscopeBtn');
const microscope = document.getElementById('microscope');
const huntZone = document.getElementById('huntZone');
const huntPepe = document.getElementById('huntPepe');
const huntResult = document.getElementById('huntResult');
const copyBtn = document.getElementById('copyBtn');
const contractText = document.getElementById('contractText');

document.getElementById('year').textContent = new Date().getFullYear();

let grow = 1;
let clicks = 0;
const growLines = [
  'MAKE HIM 1PX BIGGER',
  'OKAY. ANOTHER PIXEL.',
  'CAREFUL. HE IS MASSIVE.',
  'THIS IS GETTING MACRO.',
  'STOP. THIS IS NOT MICRO.',
];

growBtn.addEventListener('click', () => {
  clicks += 1;
  grow += 0.055;
  if (clicks > 12) {
    clicks = 0;
    grow = 1;
    growBtn.textContent = 'TOO BIG. RESET.';
    sizeTag.textContent = 'micro again';
  } else {
    growBtn.textContent = growLines[Math.min(Math.floor(clicks / 3), growLines.length - 1)];
    sizeTag.textContent = `+${clicks}px (probably)`;
  }
  microPepe.style.transform = `scale(${grow})`;
});

function toggleMicroscope() {
  microscope.classList.toggle('open');
  microscope.setAttribute('aria-hidden', microscope.classList.contains('open') ? 'false' : 'true');
}
microscopeBtn.addEventListener('click', toggleMicroscope);
microscope.addEventListener('click', toggleMicroscope);

let found = 0;
function randomizePepe() {
  const padding = 18;
  const zoneRect = huntZone.getBoundingClientRect();
  const pepeSize = huntPepe.offsetWidth || 110;
  const maxX = Math.max(padding, zoneRect.width - pepeSize - padding);
  const minY = window.innerWidth <= 820 ? 260 : padding;
  const maxY = Math.max(minY, zoneRect.height - pepeSize - padding);
  const x = padding + Math.random() * Math.max(1, maxX - padding);
  const y = minY + Math.random() * Math.max(1, maxY - minY);
  huntPepe.style.left = `${x}px`;
  huntPepe.style.top = `${y}px`;
}

huntPepe.addEventListener('click', (event) => {
  event.stopPropagation();
  found += 1;
  huntResult.textContent = `${found} frog${found === 1 ? '' : 's'} found`;
  huntPepe.animate([
    { transform: 'scale(1) rotate(0deg)' },
    { transform: 'scale(.6) rotate(10deg)' },
    { transform: 'scale(1) rotate(0deg)' },
  ], { duration: 230, easing: 'ease-out' });
  randomizePepe();
});

huntZone.addEventListener('pointerdown', (event) => {
  if (event.target !== huntPepe) {
    huntResult.textContent = found === 0 ? 'nope. smaller.' : `${found} found · missed`;
  }
});

window.addEventListener('resize', randomizePepe);
randomizePepe();

copyBtn.addEventListener('click', async () => {
  const address = copyBtn.dataset.address;
  try {
    await navigator.clipboard.writeText(address);
    copyBtn.textContent = 'COPIED';
  } catch {
    copyBtn.textContent = 'SELECT CA BELOW';
  }
  setTimeout(() => { copyBtn.textContent = 'COPY CA'; }, 1400);
});

contractText.addEventListener('click', async () => {
  try { await navigator.clipboard.writeText(contractText.textContent.trim()); } catch {}
});

// Tiny frog gets nervous if your cursor gets too close on desktop.
const field = document.getElementById('pepeField');
let fleeTimer;
field.addEventListener('pointermove', (e) => {
  if (e.pointerType === 'touch') return;
  const rect = field.getBoundingClientRect();
  const dx = e.clientX - (rect.left + rect.width / 2);
  const dy = e.clientY - (rect.top + rect.height / 2);
  const distance = Math.hypot(dx, dy);
  if (distance < Math.min(rect.width, rect.height) * .18) {
    const x = dx > 0 ? -18 : 18;
    const y = dy > 0 ? -12 : 12;
    microPepe.style.transform = `translate(${x}px, ${y}px) scale(${grow})`;
    clearTimeout(fleeTimer);
    fleeTimer = setTimeout(() => {
      microPepe.style.transform = `scale(${grow})`;
    }, 260);
  }
});
