MICRO PEPE — ready-to-run static site

Run locally / Replit:
  npm start

The server uses process.env.PORT automatically and falls back to port 3000.

Before launch, edit index.html and replace:
  PASTE_TOKEN_ADDRESS_HERE
  # links for PUMP.FUN and X / TWITTER

Main files:
  index.html
  style.css
  script.js
  server.js
  assets/micro-pepe.jpeg
